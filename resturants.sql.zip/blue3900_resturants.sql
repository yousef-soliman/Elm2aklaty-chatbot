-- phpMyAdmin SQL Dump
-- version 4.3.8
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 04, 2017 at 08:03 PM
-- Server version: 5.5.51-38.2
-- PHP Version: 5.6.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `blue3900_resturants`
--

-- --------------------------------------------------------

--
-- Table structure for table `اسماك`
--

CREATE TABLE IF NOT EXISTS `اسماك` (
  `name` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `coordinate1` double NOT NULL,
  `coordinate2` double NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `اسماك`
--

INSERT INTO `اسماك` (`name`, `coordinate1`, `coordinate2`) VALUES
('الرودي للأسماك ', 32.263244, 30.58459),
('أسماك القنال ', 32.286398, 30.604785),
('مطعم أسماك حسن ابو علي ', 32.257878, 30.58615),
('الشيماء لشوي الأسماك ', 32.262591, 30.588727),
('ابو سندس للاسماك ', 32.266224, 30.586801),
('الصلاة على النبي للمأكولات البحرية ', 32.269756, 30.580651);

-- --------------------------------------------------------

--
-- Table structure for table `بيتزا`
--

CREATE TABLE IF NOT EXISTS `بيتزا` (
  `name` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `coordinate1` double NOT NULL,
  `coordinate2` double NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `بيتزا`
--

INSERT INTO `بيتزا` (`name`, `coordinate1`, `coordinate2`) VALUES
('نابولي', 32.292264, 30.610132),
('بيتزا سبايسي ', 32.298401, 30.603951),
('بيتزا سلمى ', 32.266378, 30.590048),
('بيتزا ماسيمو ', 32.276372, 30.591597),
('بيتزا هت ', 32.271494, 30.593077),
('بيتزا كينج ', 32.271974, 30.608347),
('هوت بيتزا ', 32.285553, 30.604792),
('بيتزا تري ستيلي ', 32.276839, 30.59438),
('ميلوديز', 32.276374, 30.596144);

-- --------------------------------------------------------

--
-- Table structure for table `سوري`
--

CREATE TABLE IF NOT EXISTS `سوري` (
  `name` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `coordinate1` double NOT NULL,
  `coordinate2` double NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `سوري`
--

INSERT INTO `سوري` (`name`, `coordinate1`, `coordinate2`) VALUES
('ابو عمار', 32.290401, 30.617802),
('شيف دمشق ', 32.292327, 30.610385),
('الفروج الذهبي ', 32.279026, 30.612743),
('الدمشقي', 30612881, 32283395);

-- --------------------------------------------------------

--
-- Table structure for table `شعبي`
--

CREATE TABLE IF NOT EXISTS `شعبي` (
  `name` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `coordinate1` double NOT NULL,
  `coordinate2` double NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `شعبي`
--

INSERT INTO `شعبي` (`name`, `coordinate1`, `coordinate2`) VALUES
('فلافيلو', 32.258083, 30.558757),
('نجريللي', 32.277101, 30.59594),
('أبو علي للمأكولات الشعبية ', 32.271407, 30.613903);

-- --------------------------------------------------------

--
-- Table structure for table `مشويات`
--

CREATE TABLE IF NOT EXISTS `مشويات` (
  `name` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `coordinate1` double NOT NULL,
  `coordinate2` double NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `مشويات`
--

INSERT INTO `مشويات` (`name`, `coordinate1`, `coordinate2`) VALUES
('مشويات رضا حلمي ', 32.276471, 30.596979),
('ابو علي للمشويات ', 32.275688, 30.595697),
('اولاد السامبو', 30.612625, 32.283073),
('برنشيلي للمشويات', 32.296559, 30.605096),
('كريم حلمي للمشويات ', 32.28776, 30.610579),
('كباب حلمي', 32.2627, 30.586981),
('حضرموت ', 32.241725, 30.620578),
('مشويات ابن حلال ', 32.258476, 30.610772),
('مطعم مشويات عيسى ', 32.284349, 30.614783);

-- --------------------------------------------------------

--
-- Table structure for table `مطاعم و تيك اواي`
--

CREATE TABLE IF NOT EXISTS `مطاعم و تيك اواي` (
  `name` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `coordinate1` double NOT NULL,
  `coordinate2` double NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `مطاعم و تيك اواي`
--

INSERT INTO `مطاعم و تيك اواي` (`name`, `coordinate1`, `coordinate2`) VALUES
('spectra', 30604736, 32279819),
('كوك دور', 32.278177, 30.594065),
('هيرفي شيف ', 32.274916, 30.590811),
('كنتاكي', 32.271448, 30.593374),
('تبولة', 32.272165, 30.59654),
('Food locker  ', 32.291259, 30.617026),
('Flames ', 32.292364, 30.620756),
('Well done  ', 32.296137, 30.602204),
('Cho Cho ', 32.271088, 30.590988),
('الاستاذ طه ', 32.27355, 30.592807),
('كربيانو', 32.278973, 30.612458),
('سبايسي مكس ', 32.2741, 30.604376),
('مطعم حمزاوي ', 32.260873, 30.589911),
('أوجيني', 32.288069, 30.586839);

-- --------------------------------------------------------

--
-- Table structure for table `مطعم و كافيه`
--

CREATE TABLE IF NOT EXISTS `مطعم و كافيه` (
  `name` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `coordinate1` double NOT NULL,
  `coordinate2` double NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `مطعم و كافيه`
--

INSERT INTO `مطعم و كافيه` (`name`, `coordinate1`, `coordinate2`) VALUES
('LAVAZZA cafe', 32.281086, 30.571183),
('لابوكا', 32.306057, 30.61094),
('casino restaurant', 32.276546, 30.594733);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `اسماك`
--
ALTER TABLE `اسماك`
  ADD UNIQUE KEY `name` (`name`), ADD UNIQUE KEY `coordinate1` (`coordinate1`), ADD UNIQUE KEY `coordinate2` (`coordinate2`);

--
-- Indexes for table `بيتزا`
--
ALTER TABLE `بيتزا`
  ADD UNIQUE KEY `name` (`name`), ADD UNIQUE KEY `coordinate1` (`coordinate1`), ADD UNIQUE KEY `coordinate2` (`coordinate2`);

--
-- Indexes for table `سوري`
--
ALTER TABLE `سوري`
  ADD UNIQUE KEY `name` (`name`), ADD UNIQUE KEY `coordinate1` (`coordinate1`), ADD UNIQUE KEY `coordinate2` (`coordinate2`);

--
-- Indexes for table `شعبي`
--
ALTER TABLE `شعبي`
  ADD UNIQUE KEY `name` (`name`), ADD UNIQUE KEY `coordinate1` (`coordinate1`), ADD UNIQUE KEY `coordinate2` (`coordinate2`);

--
-- Indexes for table `مشويات`
--
ALTER TABLE `مشويات`
  ADD PRIMARY KEY (`name`);

--
-- Indexes for table `مطاعم و تيك اواي`
--
ALTER TABLE `مطاعم و تيك اواي`
  ADD UNIQUE KEY `coordinate1` (`coordinate1`), ADD UNIQUE KEY `name` (`name`), ADD UNIQUE KEY `coordinate2` (`coordinate2`);

--
-- Indexes for table `مطعم و كافيه`
--
ALTER TABLE `مطعم و كافيه`
  ADD UNIQUE KEY `name` (`name`), ADD UNIQUE KEY `coordinate1` (`coordinate1`), ADD UNIQUE KEY `coordinate2` (`coordinate2`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
